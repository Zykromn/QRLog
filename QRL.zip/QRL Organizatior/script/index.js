let number = document.getElementById("number").innerHTML = Math.floor(Math.random() * 100);
console.log(number)